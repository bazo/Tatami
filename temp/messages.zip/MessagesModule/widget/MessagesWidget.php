<?php
namespace Tatami\Modules\MessagesModule;
/**
 * Description of MessagesWidget
 *
 * @author Martin
 */
class MessagesWidget extends \Tatami\Widgets\BaseWidget 
{
    private
        $name = 'MessagesWidget'
    ;
}