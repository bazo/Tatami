<?php
namespace MessagesModule;

/**
 * MessagesPresenter
 * @author Martin Bazik
 */
class SentPresenter extends \Tatami\Modules\ModulePresenter
{
    
}
