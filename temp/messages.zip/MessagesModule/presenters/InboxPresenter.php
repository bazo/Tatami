<?php
namespace MessagesModule;

/**
 * MessagesPresenter
 * @author Martin Bazik
 */
class InboxPresenter extends \Tatami\Modules\ModulePresenter
{
    
}
